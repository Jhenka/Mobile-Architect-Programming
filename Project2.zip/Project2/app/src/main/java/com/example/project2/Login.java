package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    private EditText mUserTxt, mPassTxt;
    private Button LogIn_button, SignUp_button;
    private LoginDB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Declare XML variables
        db = new LoginDB(this);
        mUserTxt = (EditText) findViewById(R.id.Username_txt);
        mPassTxt = (EditText) findViewById(R.id.Password_txt);
        LogIn_button = findViewById(R.id.LogIn_button);
        SignUp_button = findViewById(R.id.SignUp_button);

        // Sign up / Register Account
        SignUp_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openCreateAcc();
            }
        });

        // Log In
        LogIn_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = mUserTxt.getText().toString().trim();
                String password = mPassTxt.getText().toString().trim();
                Boolean result = db.checkAcc(user, password);
                if(result == true){
                    grantAccess();
                }
                else{
                    toastMessage("Invalid Username / Password");
                }
            }
        });

    }

    // Methods
    // Create Account Activity
    public void openCreateAcc(){
        Intent intent = new Intent (this, CreateAccount.class);
        startActivity(intent);
    }

    // Grant Access to Main Activity
    public void grantAccess(){
        Intent intent = new Intent (this, MainActivity.class);
        startActivity(intent);
    }

    // Toast Message
    private void toastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
