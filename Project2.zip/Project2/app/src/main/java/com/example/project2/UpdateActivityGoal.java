package com.example.project2;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class UpdateActivityGoal extends AppCompatActivity {

    EditText goalWeight_txt;
    Button update_button;
    String gWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_goal);

        // Initialize view
        goalWeight_txt = findViewById(R.id.goalWeight_txt);
        update_button = findViewById(R.id.update_button);

        // Set actionbar
        ActionBar ab = getSupportActionBar();

        // Set Goal Weight on Button Click
        update_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newWeight = goalWeight_txt.getText().toString();
                SharedPreferences savegWeight = getSharedPreferences("myPref", 0);
                SharedPreferences.Editor editor = savegWeight.edit();
                editor.putString("Key_2", newWeight);
                editor.apply();
                finish();;
            }
        });
    }
}
