package com.example.project2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CreateAccount extends AppCompatActivity {

    private EditText mUserTxt, mPassTxt, mCellTxt;
    private Button CreateAcc_button;
    private LoginDB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        // Initialize view
        db = new LoginDB(this);
        mUserTxt = findViewById(R.id.CreateUsername_txt);
        mPassTxt = findViewById(R.id.CreatePassword_txt);
        mCellTxt = findViewById(R.id.CreateCell_txt);
        CreateAcc_button = findViewById(R.id.CreateAcc_button);

        // Button click to launch Account creation
        CreateAcc_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = mUserTxt.getText().toString().trim();
                String password = mPassTxt.getText().toString().trim();
                String cell = mCellTxt.getText().toString().trim();

                // Submit Account info to LoginDB
                long checkdb = db.addUser(user, password, cell);
                SharedPreferences saveCell = getSharedPreferences("myPref", 0);
                SharedPreferences.Editor editor = saveCell.edit();
                editor.putString("Key_3", cell);
                editor.apply();
                if (checkdb > 0) {
                    toastMessage("You Are Now Registered");
                    openLogin();
                } else {
                    toastMessage("Registration Unsuccessful");
                }
            }
        });
    }

    // Send user back to login Screen
    public void openLogin(){
        Intent intent = new Intent (this, Login.class);
        startActivity(intent);
    }

    // Toast Message
    private void toastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}

