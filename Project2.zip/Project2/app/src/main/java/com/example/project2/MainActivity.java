package com.example.project2;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    FloatingActionButton add_button;
    Button UpdateGoal_button;
    MyDatabaseHelper myDB;
    ArrayList<String> record_id, record_date, record_weight;
    CustomAdapter customAdapter;
    String gWeight;
    TextView goalWeight;
    int SMS_PERMISSION_CODE = 1;
    NotificationManagerCompat notificationManager;
    SwitchCompat switchCompat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize view
        recyclerView = findViewById(R.id.recyclerView);
        add_button = findViewById(R.id.add_button);
        UpdateGoal_button = findViewById(R.id.UpdateGoal_button);
        goalWeight = (TextView) findViewById(R.id.goalWeight);
        switchCompat = (SwitchCompat) findViewById(R.id.switchNotifications);

        // Add Action - Opens Add Activity
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddActivity.class);
                startActivity(intent);
            }
        });

        // Update Action - Opens Update Activity
        UpdateGoal_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, UpdateActivityGoal.class);
                startActivity(intent);
            }
        });

        // DB Initialization
        myDB = new MyDatabaseHelper(MainActivity.this);
        record_id = new ArrayList<>();
        record_date = new ArrayList<>();
        record_weight = new ArrayList<>();

        storeDataInArrays();

        customAdapter = new CustomAdapter(MainActivity.this,this, record_id, record_date, record_weight);
        recyclerView.setAdapter(customAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));

        // Update Goal Action - Opens Weight Goal Activity
        SharedPreferences setgoalWeight = getSharedPreferences("myPref",0);
        if(setgoalWeight.contains("Key_2")){
            gWeight = setgoalWeight.getString("Key_2",null);
        } else {
            gWeight = null;
        }
        goalWeight.setText(gWeight);

    }

    // Recreate Recycler View After submittion
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1){
            recreate();
        }
    }

    // Store data in Arrays to be viewed in Recyler View
    void storeDataInArrays(){
        Cursor cursor = myDB.readAllData();
        while (cursor.moveToNext()){
            record_id.add(cursor.getString(0));
            record_date.add(cursor.getString(1));
            record_weight.add(cursor.getString(2));
        }
    }
}